# NICEHR Platform - Complete E2E Testing Setup Guide

## 🚀 Quick Start (Step by Step)

### Step 1: Download and Extract Files

**In Replit:**
1. Download the `nicehr-cypress-tests.zip` file from Claude
2. In your Replit project, click the three dots (⋮) next to "Files"
3. Click "Upload folder" or "Upload file"
4. Upload and extract the zip file
5. Move the contents so your structure looks like:

```
your-replit-project/
├── cypress/
│   ├── e2e/
│   │   ├── 01-authentication.cy.js
│   │   ├── 02-hospitals.cy.js
│   │   ├── ... (all test files)
│   │   └── 13-admin-rbac-integrations.cy.js
│   └── support/
│       ├── commands.js
│       └── e2e.js
├── cypress.config.js
├── seed-demo-data.ts   ← Copy this file too
├── server/
├── client/
├── shared/
└── package.json
```

### Step 2: Install Cypress (if not already installed)

In your Replit Shell, run:

```bash
npm install cypress --save-dev
```

### Step 3: Seed Demo Data

**Option A: If you already have a `seed.ts` file:**
```bash
npx tsx seed.ts
```

**Option B: Use the comprehensive seeder I created:**
```bash
npx tsx seed-demo-data.ts
```

> ⚠️ **Note:** The `seed-demo-data.ts` file assumes your schema matches what's in your documentation. You may need to adjust imports at the top of the file to match your actual schema file locations.

### Step 4: Start Your Application

```bash
npm run dev
```

Wait for the server to start (usually shows something like "Server running on port 5000")

### Step 5: Run Tests

**Run all tests (headless - good for CI):**
```bash
npx cypress run
```

**Run interactively (watch tests execute):**
```bash
npx cypress open
```

**Run a specific test file:**
```bash
npx cypress run --spec "cypress/e2e/01-authentication.cy.js"
```

---

## 📝 Adding Test IDs to Your Components

For the tests to work, you need to add `data-testid` attributes to your React components. Here's how:

### Pattern Reference

| Element Type | Pattern | Example |
|--------------|---------|---------|
| Input fields | `input-{name}` | `data-testid="input-email"` |
| Buttons | `button-{action}` | `data-testid="button-submit"` |
| Select dropdowns | `select-{name}` | `data-testid="select-status"` |
| Checkboxes | `checkbox-{name}` | `data-testid="checkbox-active"` |
| Tables | `{entity}-table` | `data-testid="hospitals-table"` |
| Lists | `{entity}-list` | `data-testid="consultants-list"` |
| Table/List rows | `{entity}-row` or `{entity}-item` | `data-testid="project-item"` |
| Tabs | `tab-{name}` | `data-testid="tab-settings"` |
| Filters | `filter-{name}` | `data-testid="filter-status"` |
| Modals/Dialogs | Use `role="dialog"` | Built into shadcn/ui |

### Example: Hospital Form Component

**Before (no test IDs):**
```tsx
export function HospitalForm({ onSubmit }) {
  return (
    <form onSubmit={onSubmit}>
      <Input 
        placeholder="Hospital Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <Input 
        placeholder="Address"
        value={address}
        onChange={(e) => setAddress(e.target.value)}
      />
      <Button type="submit">Create Hospital</Button>
    </form>
  );
}
```

**After (with test IDs):**
```tsx
export function HospitalForm({ onSubmit }) {
  return (
    <form onSubmit={onSubmit}>
      <Input 
        data-testid="input-hospital-name"
        placeholder="Hospital Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <Input 
        data-testid="input-hospital-address"
        placeholder="Address"
        value={address}
        onChange={(e) => setAddress(e.target.value)}
      />
      <Button 
        data-testid="button-submit-hospital"
        type="submit"
      >
        Create Hospital
      </Button>
    </form>
  );
}
```

### Example: Table Component

**Before:**
```tsx
export function HospitalsTable({ hospitals }) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Name</TableHead>
          <TableHead>City</TableHead>
          <TableHead>Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {hospitals.map((hospital) => (
          <TableRow key={hospital.id}>
            <TableCell>{hospital.name}</TableCell>
            <TableCell>{hospital.city}</TableCell>
            <TableCell>
              <Button onClick={() => handleEdit(hospital)}>Edit</Button>
              <Button onClick={() => handleDelete(hospital)}>Delete</Button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
```

**After:**
```tsx
export function HospitalsTable({ hospitals }) {
  return (
    <Table data-testid="hospitals-table">
      <TableHeader>
        <TableRow>
          <TableHead>Name</TableHead>
          <TableHead>City</TableHead>
          <TableHead>Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {hospitals.map((hospital) => (
          <TableRow 
            key={hospital.id}
            data-testid="hospital-row"
          >
            <TableCell data-testid="hospital-name">{hospital.name}</TableCell>
            <TableCell>{hospital.city}</TableCell>
            <TableCell>
              <Button 
                data-testid="button-edit-hospital"
                onClick={() => handleEdit(hospital)}
              >
                Edit
              </Button>
              <Button 
                data-testid="button-delete-hospital"
                onClick={() => handleDelete(hospital)}
              >
                Delete
              </Button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
```

### Example: Select/Dropdown (shadcn/ui)

```tsx
<Select 
  value={status} 
  onValueChange={setStatus}
>
  <SelectTrigger data-testid="select-status">
    <SelectValue placeholder="Select status" />
  </SelectTrigger>
  <SelectContent>
    <SelectItem value="active">Active</SelectItem>
    <SelectItem value="inactive">Inactive</SelectItem>
  </SelectContent>
</Select>
```

### Example: Modal/Dialog (shadcn/ui)

```tsx
<Dialog>
  <DialogTrigger asChild>
    <Button data-testid="button-create-hospital">
      Create Hospital
    </Button>
  </DialogTrigger>
  <DialogContent>  {/* role="dialog" is automatic */}
    <DialogHeader>
      <DialogTitle>Create Hospital</DialogTitle>
    </DialogHeader>
    {/* Form content with test IDs */}
  </DialogContent>
</Dialog>
```

---

## 🔧 Files You Need to Modify

Based on your NICEHR documentation, here are the key files that need test IDs:

### Authentication
- `client/src/pages/Login.tsx` - Login form inputs and button

### Hospitals
- `client/src/pages/Hospitals.tsx` - Table, create button
- `client/src/components/HospitalForm.tsx` - Form inputs
- `client/src/components/HospitalCard.tsx` - Edit/delete buttons

### Projects
- `client/src/pages/Projects.tsx` - Table, filters
- `client/src/pages/ProjectDetail.tsx` - Tabs, phase list
- `client/src/components/ProjectForm.tsx` - Form inputs
- `client/src/components/PhaseSteps.tsx` - Step items, status selects
- `client/src/components/PhaseDeliverables.tsx` - Deliverable items
- `client/src/components/PhaseRisks.tsx` - Risk items
- `client/src/components/RACIMatrix.tsx` - Matrix cells

### Consultants
- `client/src/pages/Consultants.tsx` - Table, search, filters
- `client/src/pages/ConsultantProfile.tsx` - Tabs, sections
- `client/src/components/ConsultantForm.tsx` - Form inputs
- `client/src/components/CertificationsList.tsx` - Certification items
- `client/src/components/SkillsSection.tsx` - Skill items

### Time & Attendance
- `client/src/pages/Timesheets.tsx` - Table, approval buttons
- `client/src/pages/Schedules.tsx` - Calendar, shift items
- `client/src/components/TimesheetForm.tsx` - Form inputs
- `client/src/components/EODReportForm.tsx` - Form inputs

### Training
- `client/src/pages/Training.tsx` - Module list, tabs
- `client/src/components/TrainingModule.tsx` - Start button, progress
- `client/src/components/AssessmentForm.tsx` - Questions, answers

### Support Tickets
- `client/src/pages/SupportTickets.tsx` - Table, filters
- `client/src/pages/TicketDetail.tsx` - Status select, comments
- `client/src/components/TicketForm.tsx` - Form inputs

### Financial
- `client/src/pages/Expenses.tsx` - Table, approval buttons
- `client/src/pages/Invoices.tsx` - Table, line items
- `client/src/pages/Payroll.tsx` - Batch list
- `client/src/components/ExpenseForm.tsx` - Form inputs
- `client/src/components/InvoiceForm.tsx` - Form inputs, line items

### Travel
- `client/src/pages/Travel.tsx` - Bookings list, tabs
- `client/src/components/TravelBookingForm.tsx` - Form inputs
- `client/src/components/TravelPreferences.tsx` - Preference inputs

### Quality & Compliance
- `client/src/pages/Quality.tsx` - Tabs, scorecards
- `client/src/pages/Compliance.tsx` - Checklist, audit logs
- `client/src/components/ScorecardForm.tsx` - Rating inputs
- `client/src/components/IncidentForm.tsx` - Form inputs

### Communication
- `client/src/pages/Chat.tsx` - Channel list, message input
- `client/src/components/ChatMessage.tsx` - Message actions
- `client/src/pages/Signatures.tsx` - Request list, signature canvas

### Analytics
- `client/src/pages/Analytics.tsx` - Dashboard widgets
- `client/src/pages/Reports.tsx` - Report builder, export buttons

### Admin
- `client/src/pages/Users.tsx` - User table
- `client/src/pages/Roles.tsx` - Role list, permission matrix
- `client/src/pages/Integrations.tsx` - Integration cards

---

## 🔄 Adjusting the Seed Script

The `seed-demo-data.ts` file needs to match your actual schema. Open it and update the imports at the top:

```typescript
// Update these imports to match your actual file paths
import { db } from './server/db';  // or wherever your db instance is
import { 
  users, 
  roles, 
  // ... etc
} from './shared/schema';  // or './db/schema' depending on your setup
```

If some tables don't exist in your schema, comment out those sections of the seeder.

---

## 🐛 Troubleshooting

### "Element not found" errors
The test is looking for a `data-testid` that doesn't exist. Add it to your component.

### "Timed out waiting for element"
- The page might be loading slowly - increase timeout in `cypress.config.js`
- The element might be conditionally rendered - check your component logic

### Login tests failing
Make sure:
1. You ran the seed script
2. The test user exists: `test@example.com` / `password123`
3. Your login endpoint is at `POST /api/auth/login`

### Radix UI Select not working
The custom `cy.selectOption()` command handles this. Make sure you're using it:
```javascript
cy.selectOption('[data-testid="select-status"]', 'Active');
```

### WebSocket errors in console
These are ignored by default. If you need to test WebSocket functionality, modify `cypress/support/e2e.js`.

---

## 📊 Test Coverage Checklist

Use this to track which modules have test IDs added:

- [ ] Authentication (Login/Logout)
- [ ] Hospitals (CRUD, Units)
- [ ] Projects (CRUD, 11 Phases)
- [ ] Phase Steps
- [ ] Phase Deliverables
- [ ] Phase Risks
- [ ] Phase Milestones
- [ ] RACI Matrix
- [ ] Consultants (CRUD, Profile)
- [ ] Certifications
- [ ] Skills
- [ ] EHR Experience
- [ ] Timesheets
- [ ] Schedules
- [ ] EOD Reports
- [ ] Training Modules
- [ ] Assessments
- [ ] Login Labs
- [ ] Knowledge Base
- [ ] Support Tickets
- [ ] Expenses
- [ ] Invoices
- [ ] Payroll
- [ ] Travel Bookings
- [ ] Travel Preferences
- [ ] Scorecards
- [ ] Pulse Surveys
- [ ] Incident Reports
- [ ] HIPAA Compliance
- [ ] Chat Channels
- [ ] Direct Messages
- [ ] Digital Signatures
- [ ] Notifications
- [ ] Analytics Dashboards
- [ ] Report Builder
- [ ] User Management
- [ ] Role Management
- [ ] Integrations
- [ ] System Settings

---

## 🎯 Running Specific Test Groups

```bash
# Authentication only
npx cypress run --spec "cypress/e2e/01-authentication.cy.js"

# All project-related tests
npx cypress run --spec "cypress/e2e/03-projects.cy.js"

# Financial module tests
npx cypress run --spec "cypress/e2e/08-financial.cy.js"

# Multiple specific files
npx cypress run --spec "cypress/e2e/01-authentication.cy.js,cypress/e2e/02-hospitals.cy.js"

# All tests with video recording
npx cypress run --video

# Run in Chrome specifically
npx cypress run --browser chrome
```

---

## 💡 Tips for Success

1. **Start small** - Get authentication tests working first
2. **Add test IDs incrementally** - One module at a time
3. **Use the interactive runner** - `npx cypress open` lets you see what's happening
4. **Check the screenshots** - Failed tests save screenshots to `cypress/screenshots`
5. **Read error messages** - Cypress errors are usually very descriptive

Need help with a specific component? Just share the code and I'll show you exactly where to add the test IDs!
