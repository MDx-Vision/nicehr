const { defineConfig } = require('cypress');

module.exports = defineConfig({
  e2e: {
    baseUrl: 'http://localhost:5000',
    supportFile: 'cypress/support/e2e.js',
    specPattern: 'cypress/e2e/**/*.cy.js',
    
    // Timeouts
    defaultCommandTimeout: 10000,
    requestTimeout: 10000,
    responseTimeout: 30000,
    pageLoadTimeout: 60000,
    
    // Viewport for healthcare dashboards
    viewportWidth: 1440,
    viewportHeight: 900,
    
    // Video and screenshots
    video: true,
    screenshotOnRunFailure: true,
    
    // Retries for flaky tests
    retries: {
      runMode: 2,
      openMode: 0,
    },
    
    // Environment variables
    env: {
      testUserEmail: 'test@example.com',
      testUserPassword: 'password123',
    },
    
    setupNodeEvents(on, config) {
      // Implement node event listeners here
      on('task', {
        log(message) {
          console.log(message);
          return null;
        },
      });
      
      return config;
    },
  },
});
