/**
 * NICEHR Platform - Comprehensive Demo Data Seeding Script
 * 
 * This script populates the database with realistic demo data for:
 * - Test user with admin credentials
 * - Hospitals and units
 * - Projects with full 11-phase implementation
 * - Consultants with certifications, skills, and experience
 * - Timesheets, schedules, and EOD reports
 * - Training modules and assessments
 * - Support tickets
 * - Expenses, invoices, and payroll data
 * - Travel bookings
 * - Quality metrics (scorecards, surveys, incidents)
 * - Chat channels and messages
 * - And much more...
 * 
 * Usage: npx tsx seed.ts
 */

import { db } from './server/db';
import { 
  users, roles, permissions, rolePermissions, userRoleAssignments,
  hospitals, hospitalUnits,
  projects, projectPhases, phaseSteps, phaseDeliverables, phaseRisks, projectMilestones, raciAssignments,
  consultants, consultantCertifications, consultantSkills, skillCategories, skillItems, consultantEhrExperience,
  timesheets, schedules, eodReports,
  trainingModules, assessments, competencyRecords,
  supportTickets, ticketComments,
  expenses, invoices, invoiceLineItems, payrollBatches, payRates,
  travelBookings, travelPreferences,
  consultantScorecards, pulseSurveys, surveyResponses, incidentReports,
  chatChannels, chatMessages, channelMembers,
  signatureRequests,
  integrationConnections,
  goLiveReadinessSnapshots, consultantUtilizationSnapshots, timelineForecastSnapshots, costVarianceSnapshots
} from './shared/schema';
import { hash } from 'bcrypt';

const SALT_ROUNDS = 10;

// Helper to generate random date within range
function randomDate(start: Date, end: Date): Date {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

// Helper to pick random item from array
function randomPick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

async function seedDatabase() {
  console.log('🌱 Starting comprehensive database seeding...\n');

  try {
    // ============================================
    // 1. ROLES & PERMISSIONS
    // ============================================
    console.log('📋 Creating roles and permissions...');

    const permissionDomains = [
      'hospitals', 'projects', 'consultants', 'timesheets', 'schedules',
      'training', 'tickets', 'expenses', 'invoices', 'payroll',
      'travel', 'quality', 'compliance', 'reports', 'admin'
    ];

    const permissionActions = ['view', 'create', 'edit', 'delete'];

    // Create permissions
    const createdPermissions: any[] = [];
    for (const domain of permissionDomains) {
      for (const action of permissionActions) {
        const [perm] = await db.insert(permissions).values({
          name: `${action}_${domain}`,
          description: `Can ${action} ${domain}`,
          domain,
          action,
        }).returning();
        createdPermissions.push(perm);
      }
    }
    console.log(`   ✓ Created ${createdPermissions.length} permissions`);

    // Create base roles
    const [adminRole] = await db.insert(roles).values({
      name: 'Admin',
      description: 'Full system administrator access',
      isSystem: true,
    }).returning();

    const [managerRole] = await db.insert(roles).values({
      name: 'Manager',
      description: 'Project and team management access',
      isSystem: true,
    }).returning();

    const [consultantRole] = await db.insert(roles).values({
      name: 'Consultant',
      description: 'Standard consultant access',
      isSystem: true,
    }).returning();

    const [viewerRole] = await db.insert(roles).values({
      name: 'Viewer',
      description: 'Read-only access',
      isSystem: true,
    }).returning();

    // Assign all permissions to admin role
    for (const perm of createdPermissions) {
      await db.insert(rolePermissions).values({
        roleId: adminRole.id,
        permissionId: perm.id,
      });
    }
    console.log('   ✓ Created 4 base roles');

    // ============================================
    // 2. USERS
    // ============================================
    console.log('👤 Creating users...');

    const hashedPassword = await hash('password123', SALT_ROUNDS);

    // Test admin user
    const [testAdmin] = await db.insert(users).values({
      email: 'test@example.com',
      password: hashedPassword,
      firstName: 'Test',
      lastName: 'Admin',
      isActive: true,
    }).returning();

    await db.insert(userRoleAssignments).values({
      userId: testAdmin.id,
      roleId: adminRole.id,
    });

    // Additional users
    const userNames = [
      { first: 'Sarah', last: 'Johnson', email: 'sarah.johnson@nicehr.com', role: managerRole },
      { first: 'Michael', last: 'Chen', email: 'michael.chen@nicehr.com', role: managerRole },
      { first: 'Emily', last: 'Rodriguez', email: 'emily.rodriguez@nicehr.com', role: consultantRole },
      { first: 'David', last: 'Kim', email: 'david.kim@nicehr.com', role: consultantRole },
      { first: 'Jessica', last: 'Williams', email: 'jessica.williams@nicehr.com', role: consultantRole },
      { first: 'Robert', last: 'Taylor', email: 'robert.taylor@nicehr.com', role: viewerRole },
    ];

    const createdUsers: any[] = [testAdmin];
    for (const user of userNames) {
      const [newUser] = await db.insert(users).values({
        email: user.email,
        password: hashedPassword,
        firstName: user.first,
        lastName: user.last,
        isActive: true,
      }).returning();
      
      await db.insert(userRoleAssignments).values({
        userId: newUser.id,
        roleId: user.role.id,
      });
      
      createdUsers.push(newUser);
    }
    console.log(`   ✓ Created ${createdUsers.length} users`);

    // ============================================
    // 3. HOSPITALS & UNITS
    // ============================================
    console.log('🏥 Creating hospitals and units...');

    const hospitalData = [
      {
        name: 'Memorial General Hospital',
        address: '500 Medical Center Drive',
        city: 'Boston',
        state: 'MA',
        zip: '02115',
        phone: '617-555-0100',
        email: 'admin@memorialgeneral.org',
        units: ['ICU', 'Emergency', 'Cardiology', 'Oncology', 'Pediatrics', 'Surgery']
      },
      {
        name: 'St. Mary\'s Regional Medical Center',
        address: '1200 Healthcare Boulevard',
        city: 'Chicago',
        state: 'IL',
        zip: '60601',
        phone: '312-555-0200',
        email: 'admin@stmarysregional.org',
        units: ['ICU', 'Emergency', 'Neurology', 'Orthopedics', 'Women\'s Health']
      },
      {
        name: 'Pacific Coast University Hospital',
        address: '8900 University Avenue',
        city: 'San Francisco',
        state: 'CA',
        zip: '94102',
        phone: '415-555-0300',
        email: 'admin@pacificcoastuh.edu',
        units: ['ICU', 'Emergency', 'Research', 'Transplant', 'Burn Unit', 'Psychiatric']
      },
    ];

    const createdHospitals: any[] = [];
    for (const hosp of hospitalData) {
      const [hospital] = await db.insert(hospitals).values({
        name: hosp.name,
        address: hosp.address,
        city: hosp.city,
        state: hosp.state,
        zip: hosp.zip,
        phone: hosp.phone,
        email: hosp.email,
      }).returning();
      
      createdHospitals.push(hospital);

      // Create units for each hospital
      for (let i = 0; i < hosp.units.length; i++) {
        await db.insert(hospitalUnits).values({
          hospitalId: hospital.id,
          name: hosp.units[i],
          floor: String(i + 1),
          bedCount: Math.floor(Math.random() * 30) + 10,
        });
      }
    }
    console.log(`   ✓ Created ${createdHospitals.length} hospitals with units`);

    // ============================================
    // 4. SKILL CATEGORIES & ITEMS
    // ============================================
    console.log('🎯 Creating skill categories and items...');

    const skillData = [
      {
        category: 'Technical',
        skills: ['SQL', 'Python', 'JavaScript', 'Data Analysis', 'API Integration', 'Report Writing']
      },
      {
        category: 'EHR Systems',
        skills: ['Epic', 'Cerner', 'Meditech', 'Allscripts', 'athenahealth', 'NextGen']
      },
      {
        category: 'Clinical',
        skills: ['Clinical Workflows', 'Order Entry', 'Documentation', 'Medication Administration', 'Lab Integration']
      },
      {
        category: 'Project Management',
        skills: ['Agile', 'Scrum', 'Risk Management', 'Stakeholder Management', 'Change Management']
      },
      {
        category: 'Communication',
        skills: ['Training Delivery', 'Technical Writing', 'Presentations', 'User Support', 'Conflict Resolution']
      },
    ];

    const createdSkillCategories: any[] = [];
    const createdSkillItems: any[] = [];

    for (const cat of skillData) {
      const [category] = await db.insert(skillCategories).values({
        name: cat.category,
        description: `${cat.category} skills`,
      }).returning();
      
      createdSkillCategories.push(category);

      for (const skill of cat.skills) {
        const [item] = await db.insert(skillItems).values({
          categoryId: category.id,
          name: skill,
          description: `${skill} proficiency`,
        }).returning();
        createdSkillItems.push(item);
      }
    }
    console.log(`   ✓ Created ${createdSkillCategories.length} skill categories with ${createdSkillItems.length} skills`);

    // ============================================
    // 5. CONSULTANTS
    // ============================================
    console.log('👷 Creating consultants...');

    const consultantData = [
      { first: 'Amanda', last: 'Foster', email: 'amanda.foster@consulting.com', ehr: 'Epic', years: 8 },
      { first: 'Brian', last: 'Martinez', email: 'brian.martinez@consulting.com', ehr: 'Epic', years: 6 },
      { first: 'Catherine', last: 'Lee', email: 'catherine.lee@consulting.com', ehr: 'Cerner', years: 10 },
      { first: 'Daniel', last: 'Brown', email: 'daniel.brown@consulting.com', ehr: 'Epic', years: 4 },
      { first: 'Elena', last: 'Garcia', email: 'elena.garcia@consulting.com', ehr: 'Meditech', years: 7 },
      { first: 'Frank', last: 'Wilson', email: 'frank.wilson@consulting.com', ehr: 'Epic', years: 12 },
      { first: 'Grace', last: 'Thompson', email: 'grace.thompson@consulting.com', ehr: 'Cerner', years: 5 },
      { first: 'Henry', last: 'Anderson', email: 'henry.anderson@consulting.com', ehr: 'Allscripts', years: 9 },
      { first: 'Isabella', last: 'White', email: 'isabella.white@consulting.com', ehr: 'Epic', years: 3 },
      { first: 'James', last: 'Harris', email: 'james.harris@consulting.com', ehr: 'Epic', years: 15 },
    ];

    const createdConsultants: any[] = [];
    for (const cons of consultantData) {
      const [consultant] = await db.insert(consultants).values({
        firstName: cons.first,
        lastName: cons.last,
        email: cons.email,
        phone: `555-${String(Math.floor(Math.random() * 900) + 100)}-${String(Math.floor(Math.random() * 9000) + 1000)}`,
        address: `${Math.floor(Math.random() * 9000) + 1000} Main Street`,
        city: randomPick(['Boston', 'Chicago', 'San Francisco', 'New York', 'Seattle']),
        state: randomPick(['MA', 'IL', 'CA', 'NY', 'WA']),
        zip: String(Math.floor(Math.random() * 90000) + 10000),
        status: 'active',
        availabilityStatus: randomPick(['available', 'assigned', 'unavailable']),
      }).returning();

      createdConsultants.push(consultant);

      // Add certification
      await db.insert(consultantCertifications).values({
        consultantId: consultant.id,
        ehrSystem: cons.ehr,
        certificationName: `${cons.ehr} Certified Professional`,
        certificationDate: randomDate(new Date('2020-01-01'), new Date('2023-12-31')),
        expirationDate: randomDate(new Date('2025-01-01'), new Date('2027-12-31')),
        certificationId: `CERT-${Math.random().toString(36).substring(7).toUpperCase()}`,
        isVerified: true,
      });

      // Add EHR experience
      await db.insert(consultantEhrExperience).values({
        consultantId: consultant.id,
        ehrSystem: cons.ehr,
        yearsExperience: cons.years,
        modules: randomPick(['Ambulatory, Orders', 'Inpatient, Pharmacy', 'Revenue Cycle', 'Clinical Documentation']),
      });

      // Add random skills (3-6 per consultant)
      const numSkills = Math.floor(Math.random() * 4) + 3;
      const shuffledSkills = [...createdSkillItems].sort(() => Math.random() - 0.5).slice(0, numSkills);
      for (const skill of shuffledSkills) {
        await db.insert(consultantSkills).values({
          consultantId: consultant.id,
          skillItemId: skill.id,
          proficiencyLevel: randomPick(['beginner', 'intermediate', 'advanced', 'expert']),
          yearsExperience: Math.floor(Math.random() * 10) + 1,
        });
      }
    }
    console.log(`   ✓ Created ${createdConsultants.length} consultants with certifications and skills`);

    // ============================================
    // 6. PROJECTS WITH 11-PHASE IMPLEMENTATION
    // ============================================
    console.log('📊 Creating projects with 11-phase implementation...');

    const phaseNames = [
      { name: 'Planning', description: 'Initial planning and scope definition', durationWeeks: 4 },
      { name: 'Discovery', description: 'Requirements gathering and current state analysis', durationWeeks: 6 },
      { name: 'Design', description: 'System design and workflow mapping', durationWeeks: 8 },
      { name: 'Build', description: 'System configuration and customization', durationWeeks: 12 },
      { name: 'Unit Testing', description: 'Component-level testing', durationWeeks: 4 },
      { name: 'Integration Testing', description: 'End-to-end system testing', durationWeeks: 6 },
      { name: 'Training', description: 'End user and super user training', durationWeeks: 8 },
      { name: 'Validation', description: 'Final validation and sign-off', durationWeeks: 4 },
      { name: 'Cutover', description: 'Data migration and system cutover', durationWeeks: 2 },
      { name: 'Go-Live', description: 'Production deployment and support', durationWeeks: 2 },
      { name: 'Transition', description: 'Transition to steady-state operations', durationWeeks: 4 },
    ];

    const projectData = [
      { name: 'Epic EHR Implementation', hospital: 0, status: 'active', ehrSystem: 'Epic', budget: 5000000, completedPhases: 4 },
      { name: 'Cerner Millennium Upgrade', hospital: 1, status: 'active', ehrSystem: 'Cerner', budget: 3500000, completedPhases: 2 },
      { name: 'Meditech Expanse Rollout', hospital: 2, status: 'planning', ehrSystem: 'Meditech', budget: 4200000, completedPhases: 0 },
    ];

    const createdProjects: any[] = [];
    for (const proj of projectData) {
      const startDate = new Date();
      startDate.setMonth(startDate.getMonth() - (proj.completedPhases * 2));
      
      const targetGoLive = new Date(startDate);
      targetGoLive.setMonth(targetGoLive.getMonth() + 18);

      const [project] = await db.insert(projects).values({
        name: proj.name,
        description: `${proj.ehrSystem} implementation project for ${createdHospitals[proj.hospital].name}`,
        hospitalId: createdHospitals[proj.hospital].id,
        status: proj.status,
        ehrSystem: proj.ehrSystem,
        startDate,
        targetGoLiveDate: targetGoLive,
        budget: proj.budget,
      }).returning();

      createdProjects.push(project);

      // Create all 11 phases for each project
      let phaseStartDate = new Date(startDate);
      for (let i = 0; i < phaseNames.length; i++) {
        const phase = phaseNames[i];
        const phaseEndDate = new Date(phaseStartDate);
        phaseEndDate.setDate(phaseEndDate.getDate() + (phase.durationWeeks * 7));

        const phaseStatus = i < proj.completedPhases ? 'completed' : 
                           i === proj.completedPhases ? 'in_progress' : 'not_started';
        const completionPct = phaseStatus === 'completed' ? 100 : 
                              phaseStatus === 'in_progress' ? Math.floor(Math.random() * 60) + 20 : 0;

        const [projectPhase] = await db.insert(projectPhases).values({
          projectId: project.id,
          phaseName: phase.name,
          phaseOrder: i + 1,
          description: phase.description,
          status: phaseStatus,
          startDate: phaseStartDate,
          endDate: phaseEndDate,
          completionPercentage: completionPct,
        }).returning();

        // Add 3-5 steps per phase
        const stepNames = [
          `${phase.name} Kickoff`,
          `${phase.name} Analysis`,
          `${phase.name} Execution`,
          `${phase.name} Review`,
          `${phase.name} Sign-off`,
        ];
        
        for (let s = 0; s < stepNames.length; s++) {
          const stepStatus = phaseStatus === 'completed' ? 'completed' :
                            phaseStatus === 'in_progress' && s < 2 ? 'completed' :
                            phaseStatus === 'in_progress' && s === 2 ? 'in_progress' : 'not_started';
          
          await db.insert(phaseSteps).values({
            phaseId: projectPhase.id,
            name: stepNames[s],
            description: `${stepNames[s]} activities`,
            stepOrder: s + 1,
            status: stepStatus,
            completionPercentage: stepStatus === 'completed' ? 100 : stepStatus === 'in_progress' ? 50 : 0,
          });
        }

        // Add 2-3 deliverables per phase
        const deliverableTypes = ['Document', 'Sign-off', 'Report'];
        for (let d = 0; d < 3; d++) {
          const deliverableStatus = phaseStatus === 'completed' ? 'approved' :
                                   phaseStatus === 'in_progress' && d === 0 ? 'submitted' : 'pending';
          
          await db.insert(phaseDeliverables).values({
            phaseId: projectPhase.id,
            name: `${phase.name} ${deliverableTypes[d]}`,
            description: `Required ${deliverableTypes[d].toLowerCase()} for ${phase.name} phase`,
            dueDate: phaseEndDate,
            status: deliverableStatus,
            isRequired: d < 2,
          });
        }

        // Add 1-2 risks per phase
        if (i >= proj.completedPhases) {
          await db.insert(phaseRisks).values({
            phaseId: projectPhase.id,
            title: `${phase.name} Resource Risk`,
            description: `Potential resource constraints during ${phase.name}`,
            probability: randomPick(['low', 'medium', 'high']),
            impact: randomPick(['low', 'medium', 'high', 'critical']),
            mitigationPlan: 'Cross-train team members and maintain backup resources',
            contingencyPlan: 'Engage additional contractors if needed',
            status: 'identified',
          });
        }

        // Add milestone for each phase
        await db.insert(projectMilestones).values({
          projectId: project.id,
          phaseId: projectPhase.id,
          name: `${phase.name} Complete`,
          description: `Milestone marking completion of ${phase.name} phase`,
          dueDate: phaseEndDate,
          isCompleted: phaseStatus === 'completed',
          completedDate: phaseStatus === 'completed' ? phaseEndDate : null,
        });

        phaseStartDate = new Date(phaseEndDate);
      }

      // Assign consultants to project
      const assignedConsultants = createdConsultants.slice(0, 4);
      const raciRoles = ['responsible', 'accountable', 'consulted', 'informed'];
      for (let c = 0; c < assignedConsultants.length; c++) {
        await db.insert(raciAssignments).values({
          projectId: project.id,
          consultantId: assignedConsultants[c].id,
          role: raciRoles[c],
          phaseId: null, // Project-level assignment
        });
      }
    }
    console.log(`   ✓ Created ${createdProjects.length} projects with complete 11-phase implementation`);

    // ============================================
    // 7. TIMESHEETS & SCHEDULES
    // ============================================
    console.log('⏰ Creating timesheets and schedules...');

    const today = new Date();
    let timesheetCount = 0;
    let scheduleCount = 0;

    for (const consultant of createdConsultants.slice(0, 5)) {
      // Create timesheets for past 4 weeks
      for (let week = 0; week < 4; week++) {
        for (let day = 0; day < 5; day++) { // Mon-Fri
          const date = new Date(today);
          date.setDate(date.getDate() - (week * 7) - day);
          
          if (date.getDay() !== 0 && date.getDay() !== 6) { // Skip weekends
            await db.insert(timesheets).values({
              consultantId: consultant.id,
              projectId: randomPick(createdProjects).id,
              date,
              hours: Math.floor(Math.random() * 3) + 6, // 6-8 hours
              description: randomPick(['Implementation work', 'Training delivery', 'Documentation', 'Meetings', 'Testing']),
              taskType: randomPick(['implementation', 'training', 'support', 'documentation']),
              status: week > 1 ? 'approved' : week === 1 ? 'pending' : 'draft',
            });
            timesheetCount++;
          }
        }
      }

      // Create schedules for next 2 weeks
      for (let week = 0; week < 2; week++) {
        for (let day = 0; day < 5; day++) {
          const date = new Date(today);
          date.setDate(date.getDate() + (week * 7) + day);
          
          if (date.getDay() !== 0 && date.getDay() !== 6) {
            await db.insert(schedules).values({
              consultantId: consultant.id,
              projectId: randomPick(createdProjects).id,
              date,
              startTime: '08:00',
              endTime: '17:00',
              shiftType: randomPick(['day', 'swing']),
              status: 'scheduled',
            });
            scheduleCount++;
          }
        }
      }

      // Create EOD reports
      for (let d = 0; d < 5; d++) {
        const date = new Date(today);
        date.setDate(date.getDate() - d);
        
        if (date.getDay() !== 0 && date.getDay() !== 6) {
          await db.insert(eodReports).values({
            consultantId: consultant.id,
            projectId: randomPick(createdProjects).id,
            date,
            accomplishments: 'Completed user training session, resolved 3 support tickets',
            challenges: 'Network connectivity issues in Unit 3',
            tomorrowPlan: 'Continue with go-live preparations',
          });
        }
      }
    }
    console.log(`   ✓ Created ${timesheetCount} timesheets and ${scheduleCount} schedules`);

    // ============================================
    // 8. TRAINING MODULES & ASSESSMENTS
    // ============================================
    console.log('📚 Creating training modules and assessments...');

    const trainingData = [
      { name: 'Epic Foundations', category: 'EHR', duration: 120, difficulty: 'beginner' },
      { name: 'Epic Orders Management', category: 'EHR', duration: 90, difficulty: 'intermediate' },
      { name: 'Epic Clinical Documentation', category: 'EHR', duration: 180, difficulty: 'advanced' },
      { name: 'HIPAA Compliance Training', category: 'Compliance', duration: 60, difficulty: 'beginner' },
      { name: 'Change Management Fundamentals', category: 'Soft Skills', duration: 90, difficulty: 'intermediate' },
      { name: 'Project Go-Live Best Practices', category: 'Implementation', duration: 120, difficulty: 'advanced' },
    ];

    const createdModules: any[] = [];
    for (const training of trainingData) {
      const [module] = await db.insert(trainingModules).values({
        name: training.name,
        description: `Comprehensive training on ${training.name}`,
        category: training.category,
        durationMinutes: training.duration,
        difficulty: training.difficulty,
        isRequired: training.category === 'Compliance',
        isActive: true,
      }).returning();
      
      createdModules.push(module);

      // Create assessment for each module
      await db.insert(assessments).values({
        moduleId: module.id,
        name: `${training.name} Assessment`,
        description: `Knowledge check for ${training.name}`,
        passingScore: 80,
        timeLimitMinutes: 30,
        maxAttempts: 3,
        isActive: true,
      });
    }

    // Create competency records for consultants
    for (const consultant of createdConsultants.slice(0, 5)) {
      for (const module of createdModules.slice(0, 3)) {
        await db.insert(competencyRecords).values({
          consultantId: consultant.id,
          moduleId: module.id,
          completionDate: randomDate(new Date('2024-01-01'), new Date()),
          score: Math.floor(Math.random() * 20) + 80,
          status: 'completed',
        });
      }
    }
    console.log(`   ✓ Created ${createdModules.length} training modules with assessments`);

    // ============================================
    // 9. SUPPORT TICKETS
    // ============================================
    console.log('🎫 Creating support tickets...');

    const ticketSubjects = [
      'Login issues in Epic',
      'Order entry not working',
      'Training schedule question',
      'System running slowly',
      'Need access to reports',
      'Documentation upload failed',
      'Password reset request',
      'Integration error with lab system',
    ];

    let ticketCount = 0;
    for (let i = 0; i < 20; i++) {
      const createdDate = randomDate(new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000), today);
      const status = randomPick(['open', 'in_progress', 'resolved', 'closed']);
      
      const [ticket] = await db.insert(supportTickets).values({
        subject: randomPick(ticketSubjects),
        description: 'Detailed description of the issue being reported.',
        category: randomPick(['technical', 'training', 'access', 'general']),
        priority: randomPick(['low', 'medium', 'high', 'critical']),
        status,
        projectId: randomPick(createdProjects).id,
        createdById: randomPick(createdUsers).id,
        assignedToId: status !== 'open' ? randomPick(createdUsers).id : null,
        createdAt: createdDate,
        resolvedAt: status === 'resolved' || status === 'closed' ? new Date() : null,
      }).returning();

      // Add comment to ticket
      await db.insert(ticketComments).values({
        ticketId: ticket.id,
        userId: randomPick(createdUsers).id,
        content: 'Working on this issue. Will update shortly.',
        isInternal: Math.random() > 0.7,
      });

      ticketCount++;
    }
    console.log(`   ✓ Created ${ticketCount} support tickets`);

    // ============================================
    // 10. FINANCIAL DATA
    // ============================================
    console.log('💰 Creating financial data...');

    // Expenses
    let expenseCount = 0;
    const expenseCategories = ['Travel', 'Meals', 'Lodging', 'Equipment', 'Software', 'Training'];
    for (const consultant of createdConsultants.slice(0, 5)) {
      for (let e = 0; e < 5; e++) {
        const expenseDate = randomDate(new Date(today.getTime() - 60 * 24 * 60 * 60 * 1000), today);
        await db.insert(expenses).values({
          consultantId: consultant.id,
          projectId: randomPick(createdProjects).id,
          category: randomPick(expenseCategories),
          vendor: randomPick(['Delta Airlines', 'Marriott', 'Uber', 'Amazon', 'Best Buy']),
          amount: Math.floor(Math.random() * 500) + 50,
          description: 'Project-related expense',
          expenseDate,
          status: randomPick(['draft', 'pending', 'approved', 'rejected']),
        });
        expenseCount++;
      }
    }
    console.log(`   ✓ Created ${expenseCount} expenses`);

    // Invoices
    for (const project of createdProjects) {
      for (let m = 0; m < 3; m++) {
        const invoiceDate = new Date(today);
        invoiceDate.setMonth(invoiceDate.getMonth() - m);
        
        const dueDate = new Date(invoiceDate);
        dueDate.setDate(dueDate.getDate() + 30);

        const [invoice] = await db.insert(invoices).values({
          projectId: project.id,
          hospitalId: project.hospitalId,
          invoiceNumber: `INV-${project.id}-${String(m + 1).padStart(3, '0')}`,
          invoiceDate,
          dueDate,
          subtotal: 50000 + (m * 10000),
          tax: 0,
          total: 50000 + (m * 10000),
          status: m > 0 ? 'paid' : 'pending',
        }).returning();

        await db.insert(invoiceLineItems).values({
          invoiceId: invoice.id,
          description: 'Consulting Services',
          quantity: 160,
          rate: (50000 + (m * 10000)) / 160,
          amount: 50000 + (m * 10000),
        });
      }
    }
    console.log(`   ✓ Created invoices for all projects`);

    // Pay rates
    for (const consultant of createdConsultants) {
      await db.insert(payRates).values({
        consultantId: consultant.id,
        rateType: 'hourly',
        rate: Math.floor(Math.random() * 50) + 75, // $75-125/hour
        effectiveDate: new Date('2024-01-01'),
      });
    }
    console.log(`   ✓ Created pay rates for all consultants`);

    // ============================================
    // 11. TRAVEL DATA
    // ============================================
    console.log('✈️ Creating travel data...');

    for (const consultant of createdConsultants.slice(0, 5)) {
      // Travel preferences
      await db.insert(travelPreferences).values({
        consultantId: consultant.id,
        preferredAirline: randomPick(['Delta', 'United', 'American', 'Southwest']),
        frequentFlyerNumber: `FF${Math.random().toString(36).substring(7).toUpperCase()}`,
        seatPreference: randomPick(['aisle', 'window', 'no_preference']),
        preferredHotel: randomPick(['Marriott', 'Hilton', 'Hyatt', 'IHG']),
        hotelLoyaltyNumber: `HL${Math.random().toString(36).substring(7).toUpperCase()}`,
        dietaryRestrictions: randomPick(['None', 'Vegetarian', 'Gluten-free', '']),
      });

      // Travel bookings
      for (let b = 0; b < 2; b++) {
        const departureDate = new Date(today);
        departureDate.setDate(departureDate.getDate() + (b * 14) + 7);
        
        const returnDate = new Date(departureDate);
        returnDate.setDate(returnDate.getDate() + 4);

        await db.insert(travelBookings).values({
          consultantId: consultant.id,
          projectId: randomPick(createdProjects).id,
          bookingType: 'flight',
          departureCity: randomPick(['Boston', 'New York', 'Chicago']),
          arrivalCity: randomPick(['San Francisco', 'Los Angeles', 'Seattle']),
          departureDate,
          returnDate,
          airline: randomPick(['Delta', 'United', 'American']),
          confirmationNumber: `CONF${Math.random().toString(36).substring(7).toUpperCase()}`,
          cost: Math.floor(Math.random() * 300) + 200,
          status: 'confirmed',
        });
      }
    }
    console.log(`   ✓ Created travel preferences and bookings`);

    // ============================================
    // 12. QUALITY DATA
    // ============================================
    console.log('⭐ Creating quality data...');

    // Consultant scorecards
    for (const consultant of createdConsultants.slice(0, 5)) {
      await db.insert(consultantScorecards).values({
        consultantId: consultant.id,
        projectId: randomPick(createdProjects).id,
        evaluationPeriod: 'Q1 2024',
        technicalScore: Math.floor(Math.random() * 2) + 4, // 4-5
        communicationScore: Math.floor(Math.random() * 2) + 4,
        teamworkScore: Math.floor(Math.random() * 2) + 4,
        punctualityScore: Math.floor(Math.random() * 2) + 4,
        overallScore: Math.floor(Math.random() * 2) + 4,
        comments: 'Excellent performance during the evaluation period.',
        evaluatorId: createdUsers[1].id,
      });
    }

    // Pulse surveys
    const [survey] = await db.insert(pulseSurveys).values({
      title: 'Weekly Team Check-in',
      description: 'Quick weekly feedback survey',
      targetAudience: 'all_consultants',
      dueDate: new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000),
      status: 'active',
      createdById: createdUsers[0].id,
    }).returning();

    // Survey responses
    for (const consultant of createdConsultants.slice(0, 5)) {
      await db.insert(surveyResponses).values({
        surveyId: survey.id,
        respondentId: consultant.id,
        responses: JSON.stringify({ satisfaction: 4, workload: 3, support: 5 }),
        submittedAt: new Date(),
      });
    }

    // Incident reports
    await db.insert(incidentReports).values({
      title: 'System Access Issue',
      description: 'Users unable to access system during scheduled maintenance window',
      incidentDate: new Date(today.getTime() - 5 * 24 * 60 * 60 * 1000),
      incidentType: 'technical',
      severity: 'medium',
      projectId: createdProjects[0].id,
      reportedById: createdUsers[0].id,
      status: 'resolved',
      resolution: 'Extended maintenance window and improved communication',
    });
    console.log(`   ✓ Created scorecards, surveys, and incident reports`);

    // ============================================
    // 13. CHAT DATA
    // ============================================
    console.log('💬 Creating chat data...');

    const channels = [
      { name: 'General', description: 'General discussion', type: 'public' },
      { name: 'Epic Implementation', description: 'Epic project team', type: 'public' },
      { name: 'Training Team', description: 'Training coordinators', type: 'private' },
    ];

    for (const ch of channels) {
      const [channel] = await db.insert(chatChannels).values({
        name: ch.name,
        description: ch.description,
        channelType: ch.type,
        createdById: createdUsers[0].id,
      }).returning();

      // Add members
      for (const user of createdUsers.slice(0, 4)) {
        await db.insert(channelMembers).values({
          channelId: channel.id,
          userId: user.id,
        });
      }

      // Add messages
      const messages = [
        'Good morning team!',
        'Reminder: Stand-up at 9am',
        'Great progress on the implementation!',
        'Any blockers to discuss?',
        'Training materials have been updated',
      ];

      for (let m = 0; m < 5; m++) {
        await db.insert(chatMessages).values({
          channelId: channel.id,
          senderId: randomPick(createdUsers).id,
          content: messages[m],
          createdAt: new Date(today.getTime() - m * 60 * 60 * 1000),
        });
      }
    }
    console.log(`   ✓ Created ${channels.length} chat channels with messages`);

    // ============================================
    // 14. ANALYTICS SNAPSHOTS
    // ============================================
    console.log('📈 Creating analytics snapshots...');

    for (const project of createdProjects) {
      // Go-Live Readiness
      await db.insert(goLiveReadinessSnapshots).values({
        projectId: project.id,
        snapshotDate: new Date(),
        overallScore: Math.floor(Math.random() * 30) + 70,
        trainingReadiness: Math.floor(Math.random() * 20) + 80,
        technicalReadiness: Math.floor(Math.random() * 25) + 75,
        operationalReadiness: Math.floor(Math.random() * 30) + 70,
        blockers: JSON.stringify(['Final testing pending', 'User acceptance pending']),
      });

      // Timeline Forecast
      await db.insert(timelineForecastSnapshots).values({
        projectId: project.id,
        snapshotDate: new Date(),
        projectedGoLive: project.targetGoLiveDate,
        scheduleVarianceDays: Math.floor(Math.random() * 20) - 10,
        confidenceLevel: Math.floor(Math.random() * 20) + 80,
      });

      // Cost Variance
      await db.insert(costVarianceSnapshots).values({
        projectId: project.id,
        snapshotDate: new Date(),
        budgetedCost: project.budget,
        actualCost: project.budget * (0.8 + Math.random() * 0.3),
        varianceAmount: project.budget * (Math.random() * 0.2 - 0.1),
        variancePercentage: Math.random() * 20 - 10,
      });
    }

    // Consultant Utilization
    for (const consultant of createdConsultants.slice(0, 5)) {
      await db.insert(consultantUtilizationSnapshots).values({
        consultantId: consultant.id,
        snapshotDate: new Date(),
        billableHours: Math.floor(Math.random() * 20) + 140,
        totalHours: 160,
        utilizationRate: Math.floor(Math.random() * 15) + 85,
      });
    }
    console.log(`   ✓ Created analytics snapshots`);

    // ============================================
    // 15. INTEGRATIONS
    // ============================================
    console.log('🔗 Creating integration connections...');

    const integrations = [
      { system: 'Google Calendar', type: 'calendar', status: 'connected' },
      { system: 'ADP Payroll', type: 'payroll', status: 'connected' },
      { system: 'Epic', type: 'ehr', status: 'pending' },
    ];

    for (const int of integrations) {
      await db.insert(integrationConnections).values({
        systemName: int.system,
        integrationType: int.type,
        status: int.status,
        lastSyncAt: int.status === 'connected' ? new Date() : null,
        configData: JSON.stringify({ enabled: true }),
      });
    }
    console.log(`   ✓ Created ${integrations.length} integration connections`);

    // ============================================
    // COMPLETE
    // ============================================
    console.log('\n✅ Database seeding completed successfully!\n');
    console.log('📊 Summary:');
    console.log(`   • ${createdPermissions.length} permissions`);
    console.log(`   • 4 roles`);
    console.log(`   • ${createdUsers.length} users`);
    console.log(`   • ${createdHospitals.length} hospitals`);
    console.log(`   • ${createdSkillItems.length} skills across ${createdSkillCategories.length} categories`);
    console.log(`   • ${createdConsultants.length} consultants`);
    console.log(`   • ${createdProjects.length} projects (each with 11 phases)`);
    console.log(`   • ${timesheetCount} timesheets`);
    console.log(`   • ${scheduleCount} schedules`);
    console.log(`   • ${createdModules.length} training modules`);
    console.log(`   • ${ticketCount} support tickets`);
    console.log(`   • Financial records (expenses, invoices, pay rates)`);
    console.log(`   • Travel bookings and preferences`);
    console.log(`   • Quality metrics (scorecards, surveys, incidents)`);
    console.log(`   • Chat channels and messages`);
    console.log(`   • Analytics snapshots`);
    console.log(`   • Integration connections`);
    console.log('\n🔐 Test User Credentials:');
    console.log('   Email: test@example.com');
    console.log('   Password: password123');
    console.log('   Role: Admin (full access)\n');

  } catch (error) {
    console.error('❌ Error seeding database:', error);
    throw error;
  }
}

// Run the seeder
seedDatabase()
  .then(() => process.exit(0))
  .catch(() => process.exit(1));
