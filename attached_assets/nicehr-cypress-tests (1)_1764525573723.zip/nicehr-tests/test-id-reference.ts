/**
 * NICEHR Platform - Test ID Reference
 * 
 * This file documents all data-testid attributes used by the Cypress tests.
 * Use this as a reference when adding test IDs to your components.
 * 
 * Format: testId -> description (used in which test file)
 */

export const TEST_IDS = {
  // ============================================
  // AUTHENTICATION (01-authentication.cy.js)
  // ============================================
  auth: {
    // Login form
    'input-email': 'Email input field on login page',
    'input-password': 'Password input field on login page',
    'button-login': 'Login submit button',
    'toggle-password-visibility': 'Show/hide password toggle',
    'error-message': 'Login error message display',
    
    // User menu
    'user-menu': 'User profile dropdown trigger',
    'button-logout': 'Logout button in user menu',
    
    // Navigation
    'nav-dashboard': 'Dashboard navigation link',
    'nav-users': 'Users management nav (admin only)',
    'nav-roles': 'Roles management nav (admin only)',
  },

  // ============================================
  // HOSPITALS (02-hospitals.cy.js)
  // ============================================
  hospitals: {
    // List view
    'hospitals-table': 'Main hospitals table',
    'hospitals-list': 'Alternative list view',
    'input-search': 'Search hospitals input',
    'filter-hospitals': 'Hospital filter dropdown',
    
    // Create/Edit form
    'button-create-hospital': 'Create new hospital button',
    'input-hospital-name': 'Hospital name input',
    'input-hospital-address': 'Hospital address input',
    'input-hospital-city': 'Hospital city input',
    'input-hospital-state': 'Hospital state input',
    'input-hospital-zip': 'Hospital zip code input',
    'input-hospital-phone': 'Hospital phone input',
    'input-hospital-email': 'Hospital email input',
    'button-submit-hospital': 'Submit hospital form',
    'error-hospital-name': 'Hospital name validation error',
    
    // Actions
    'button-edit-hospital': 'Edit hospital button (in row)',
    'button-delete-hospital': 'Delete hospital button (in row)',
    'button-cancel-delete': 'Cancel delete confirmation',
    'confirm-dialog': 'Delete confirmation dialog',
    
    // Detail view
    'hospital-name': 'Hospital name display',
    'hospital-address': 'Hospital address display',
    'hospital-units': 'Hospital units section',
    'hospital-projects': 'Associated projects section',
    'units-section': 'Units section container',
    'projects-section': 'Projects section container',
    
    // Units
    'button-add-unit': 'Add unit button',
    'input-unit-name': 'Unit name input',
    'input-unit-floor': 'Unit floor input',
    'input-unit-bed-count': 'Unit bed count input',
    'button-submit-unit': 'Submit unit form',
    'units-list': 'Units list container',
    'button-edit-unit': 'Edit unit button',
    'button-delete-unit': 'Delete unit button',
  },

  // ============================================
  // PROJECTS (03-projects.cy.js)
  // ============================================
  projects: {
    // List view
    'projects-table': 'Main projects table',
    'projects-list': 'Alternative list view',
    'project-status': 'Project status badge',
    'filter-status': 'Status filter dropdown',
    'filter-hospital': 'Hospital filter dropdown',
    
    // Create/Edit form
    'button-create-project': 'Create new project button',
    'input-project-name': 'Project name input',
    'input-project-description': 'Project description input',
    'select-hospital': 'Hospital selection dropdown',
    'select-ehr-system': 'EHR system selection',
    'input-start-date': 'Project start date',
    'input-target-go-live': 'Target go-live date',
    'input-budget': 'Project budget input',
    'button-submit-project': 'Submit project form',
    
    // Actions
    'button-edit-project': 'Edit project button',
    'button-delete-project': 'Delete project button',
    
    // Detail view
    'project-name': 'Project name display',
    'project-hospital': 'Associated hospital display',
    'project-progress': 'Project progress indicator',
    'progress-bar': 'Progress bar component',
    'assigned-consultants': 'Assigned consultants section',
    
    // Tabs
    'tab-team': 'Team tab trigger',
    'tab-raci': 'RACI matrix tab trigger',
  },

  // ============================================
  // PHASES (03-projects.cy.js)
  // ============================================
  phases: {
    // Phase list
    'phases-list': 'List of all 11 phases',
    'phase-item': 'Individual phase item',
    'phase-timeline': 'Phase timeline view',
    'phase-completion': 'Phase completion percentage',
    'phase-status': 'Phase status indicator',
    
    // Phase steps
    'phase-steps-list': 'Steps within a phase',
    'button-add-step': 'Add step button',
    'input-step-name': 'Step name input',
    'input-step-description': 'Step description input',
    'input-step-order': 'Step order input',
    'button-submit-step': 'Submit step form',
    'step-item': 'Individual step item',
    'select-step-status': 'Step status dropdown',
    'step-status': 'Step status display',
    'button-delete-step': 'Delete step button',
    
    // Phase deliverables
    'tab-deliverables': 'Deliverables tab trigger',
    'deliverables-list': 'Deliverables list',
    'button-add-deliverable': 'Add deliverable button',
    'input-deliverable-name': 'Deliverable name input',
    'input-deliverable-description': 'Deliverable description',
    'input-due-date': 'Deliverable due date',
    'select-deliverable-type': 'Deliverable type select',
    'button-submit-deliverable': 'Submit deliverable form',
    'deliverable-item': 'Individual deliverable item',
    'deliverable-status': 'Deliverable status display',
    'button-submit-deliverable': 'Submit for approval button',
    'button-approve-deliverable': 'Approve deliverable button',
    'button-attach-file': 'Attach file button',
    
    // Phase risks
    'tab-risks': 'Risks tab trigger',
    'risks-list': 'Risks list',
    'button-add-risk': 'Add risk button',
    'input-risk-title': 'Risk title input',
    'input-risk-description': 'Risk description input',
    'select-risk-probability': 'Risk probability select',
    'select-risk-impact': 'Risk impact select',
    'input-mitigation-plan': 'Mitigation plan input',
    'input-contingency-plan': 'Contingency plan input',
    'button-submit-risk': 'Submit risk form',
    'risk-item': 'Individual risk item',
    'risk-score': 'Risk score display',
    'risk-matrix': 'Risk matrix visualization',
    'select-risk-status': 'Risk status dropdown',
    'risk-status': 'Risk status display',
    
    // Phase milestones
    'tab-milestones': 'Milestones tab trigger',
    'milestones-list': 'Milestones list',
    'button-add-milestone': 'Add milestone button',
    'input-milestone-name': 'Milestone name input',
    'input-milestone-description': 'Milestone description',
    'input-milestone-due-date': 'Milestone due date',
    'button-submit-milestone': 'Submit milestone form',
    'milestone-item': 'Individual milestone item',
    'milestone-status': 'Milestone status display',
    'button-complete-milestone': 'Mark milestone complete',
    
    // RACI Matrix
    'raci-matrix': 'RACI matrix table',
    'raci-cell': 'Individual RACI cell',
    'filter-raci-phase': 'RACI phase filter',
    'button-export-raci': 'Export RACI button',
  },

  // ============================================
  // CONSULTANTS (04-consultants.cy.js)
  // ============================================
  consultants: {
    // List view
    'consultants-table': 'Main consultants table',
    'consultants-list': 'Alternative list view',
    'input-search': 'Search consultants input',
    'filter-ehr': 'EHR certification filter',
    'filter-availability': 'Availability filter',
    'filter-skills': 'Skills filter',
    'consultant-certifications': 'Certifications badges display',
    
    // Create/Edit form
    'button-create-consultant': 'Create consultant button',
    'input-first-name': 'First name input',
    'input-last-name': 'Last name input',
    'input-email': 'Email input',
    'input-phone': 'Phone input',
    'input-address': 'Address input',
    'input-city': 'City input',
    'input-state': 'State input',
    'input-zip': 'Zip code input',
    'button-submit-consultant': 'Submit consultant form',
    
    // Profile view
    'consultant-profile': 'Consultant profile container',
    'consultant-name': 'Consultant name display',
    'consultant-email': 'Consultant email display',
    'consultant-phone': 'Consultant phone display',
    'consultant-skills': 'Skills section',
    'consultant-projects': 'Projects history',
    'project-history': 'Project history section',
    'ehr-badges': 'EHR certification badges',
    
    // Tabs
    'tab-certifications': 'Certifications tab',
    'tab-skills': 'Skills tab',
    'tab-ehr-experience': 'EHR experience tab',
    'tab-questionnaire': 'Questionnaire tab',
    'tab-documents': 'Documents tab',
    'tab-onboarding': 'Onboarding tab',
    
    // Certifications
    'certifications-list': 'Certifications list',
    'button-add-certification': 'Add certification button',
    'select-ehr-system': 'EHR system select',
    'input-certification-date': 'Certification date input',
    'input-expiration-date': 'Expiration date input',
    'input-certification-id': 'Certification ID input',
    'button-submit-certification': 'Submit certification form',
    'certification-item': 'Individual certification item',
    'certification-expiring': 'Expiring certification warning',
    'button-verify-certification': 'Verify certification button',
    
    // Skills
    'skill-categories': 'Skill categories container',
    'button-add-skill': 'Add skill button',
    'select-skill-category': 'Skill category select',
    'select-skill': 'Skill select',
    'select-proficiency': 'Proficiency level select',
    'input-years-experience': 'Years experience input',
    'button-submit-skill': 'Submit skill form',
    'skill-item': 'Individual skill item',
    'button-verify-skill': 'Verify skill button',
    
    // Actions
    'button-edit-consultant': 'Edit consultant button',
    'button-delete-consultant': 'Delete consultant button',
    'button-advanced-search': 'Advanced search button',
    'advanced-search-panel': 'Advanced search panel',
    'input-min-experience': 'Minimum experience filter',
    'button-apply-filters': 'Apply filters button',
    'button-clear-filters': 'Clear filters button',
  },

  // ============================================
  // TIME & ATTENDANCE (05-time-attendance.cy.js)
  // ============================================
  timesheets: {
    // List view
    'timesheets-table': 'Timesheets table',
    'timesheets-list': 'Timesheets list view',
    'timesheet-row': 'Individual timesheet row',
    'input-start-date': 'Start date filter',
    'input-end-date': 'End date filter',
    'button-apply-filter': 'Apply date filter button',
    'filter-status': 'Status filter',
    'filter-consultant': 'Consultant filter',
    
    // Create/Edit
    'button-create-timesheet': 'Create timesheet button',
    'input-date': 'Timesheet date input',
    'select-project': 'Project select',
    'input-hours': 'Hours input',
    'input-description': 'Description input',
    'select-task-type': 'Task type select',
    'button-submit-timesheet': 'Submit timesheet form',
    
    // Approval
    'button-submit-approval': 'Submit for approval button',
    'button-approve': 'Approve timesheet button',
    'button-reject': 'Reject timesheet button',
    'input-rejection-reason': 'Rejection reason input',
    'button-confirm-reject': 'Confirm rejection button',
    'checkbox-select-all': 'Select all checkbox',
    'button-bulk-approve': 'Bulk approve button',
    'timesheet-status': 'Timesheet status display',
    
    // Actions
    'button-edit-timesheet': 'Edit timesheet button',
    'button-delete-timesheet': 'Delete timesheet button',
    
    // Summary
    'tab-weekly-summary': 'Weekly summary tab',
    'weekly-hours-total': 'Weekly hours total',
    'project-hours-breakdown': 'Hours by project breakdown',
    'button-export-timesheets': 'Export timesheets button',
    'select-export-format': 'Export format select',
    'button-download': 'Download button',
  },

  schedules: {
    // Calendar view
    'schedule-calendar': 'Schedule calendar component',
    'schedule-week-view': 'Week view',
    'schedule-month-view': 'Month view',
    'button-view-week': 'Week view button',
    'button-view-month': 'Month view button',
    'button-next-week': 'Next week button',
    'button-prev-week': 'Previous week button',
    'filter-consultant': 'Consultant filter',
    'filter-project': 'Project filter',
    
    // Shifts
    'button-create-shift': 'Create shift button',
    'select-consultant': 'Consultant select',
    'select-project': 'Project select',
    'input-shift-date': 'Shift date input',
    'input-start-time': 'Start time input',
    'input-end-time': 'End time input',
    'select-shift-type': 'Shift type select',
    'checkbox-recurring': 'Recurring shift checkbox',
    'select-recurrence': 'Recurrence pattern select',
    'input-recurrence-end': 'Recurrence end date',
    'button-submit-shift': 'Submit shift form',
    'shift-item': 'Individual shift item',
    'button-delete-shift': 'Delete shift button',
    
    // Availability
    'tab-availability': 'Availability tab',
    'availability-grid': 'Availability grid',
    'availability-slot': 'Availability slot',
    'select-availability-status': 'Availability status select',
    'button-save-availability': 'Save availability button',
    'button-request-time-off': 'Request time off button',
    'input-reason': 'Time off reason input',
    'button-submit-request': 'Submit time off request',
    
    // Sign-in/out
    'button-sign-in': 'Sign in button',
    'button-sign-out': 'Sign out button',
    'sign-in-time': 'Sign in time display',
    'sign-out-time': 'Sign out time display',
    'tab-sign-in-history': 'Sign-in history tab',
    'sign-in-records': 'Sign-in records list',
  },

  eodReports: {
    'tab-eod-reports': 'EOD reports tab',
    'eod-reports-list': 'EOD reports list',
    'button-create-eod-report': 'Create EOD report button',
    'input-accomplishments': 'Accomplishments input',
    'input-challenges': 'Challenges input',
    'input-tomorrow-plan': 'Tomorrow plan input',
    'button-submit-eod': 'Submit EOD report button',
    'eod-report-item': 'Individual EOD report',
    'eod-report-details': 'EOD report details view',
  },

  handoffNotes: {
    'tab-handoff-notes': 'Handoff notes tab',
    'handoff-notes-list': 'Handoff notes list',
    'button-create-handoff': 'Create handoff note button',
    'input-handoff-summary': 'Handoff summary input',
    'input-outstanding-items': 'Outstanding items input',
    'select-priority': 'Priority select',
    'button-submit-handoff': 'Submit handoff form',
    'handoff-note-item': 'Individual handoff note',
    'button-acknowledge': 'Acknowledge handoff button',
  },

  // ============================================
  // Continue with more modules...
  // ============================================
  
  // Common/shared test IDs used across modules
  common: {
    'loading-indicator': 'Loading spinner/indicator',
    'button-confirm': 'Generic confirm button',
    'button-cancel': 'Generic cancel button',
    'button-confirm-delete': 'Confirm delete button',
    'button-cancel-delete': 'Cancel delete button',
    'error-message': 'Error message display',
    'success-message': 'Success message display',
    'toast': 'Toast notification',
    'modal': 'Modal dialog (also use role="dialog")',
    'button-close': 'Close button',
  },
};

/**
 * Helper function to generate test ID
 * Usage: getTestId('hospitals', 'input-hospital-name')
 */
export function getTestId(module: keyof typeof TEST_IDS, id: string): string {
  return `data-testid="${id}"`;
}

/**
 * Component helper - returns object with all test IDs for a module
 * Usage in React: <Input {...testIds.hospitals['input-hospital-name']} />
 */
export const testIdProps = Object.entries(TEST_IDS).reduce((acc, [module, ids]) => {
  acc[module] = Object.keys(ids).reduce((moduleAcc, id) => {
    moduleAcc[id] = { 'data-testid': id };
    return moduleAcc;
  }, {} as Record<string, { 'data-testid': string }>);
  return acc;
}, {} as Record<string, Record<string, { 'data-testid': string }>>);
