# NICEHR Platform - Comprehensive E2E Test Suite

This test suite provides complete end-to-end testing coverage for the NICEHR Healthcare Consultant Management Platform.

## Test Coverage

| Test File | Module | Tests |
|-----------|--------|-------|
| `01-authentication.cy.js` | Authentication | Login, logout, session, RBAC |
| `02-hospitals.cy.js` | Hospital Management | CRUD, units, associated projects |
| `03-projects.cy.js` | Projects & 11-Phase Workflow | Projects, phases, steps, deliverables, risks, milestones, RACI |
| `04-consultants.cy.js` | Consultant Management | Profiles, certifications, skills, onboarding |
| `05-time-attendance.cy.js` | Time & Attendance | Timesheets, schedules, EOD reports, handoffs |
| `06-training-competency.cy.js` | Training & Competency | Training portal, assessments, login labs, knowledge base |
| `07-support-tickets.cy.js` | Support Tickets | CRUD, status workflow, SLA tracking |
| `08-financial.cy.js` | Financial Management | Expenses, invoices, payroll, budgets |
| `09-travel.cy.js` | Travel Management | Bookings, preferences, itineraries, approvals |
| `10-quality-compliance.cy.js` | Quality & Compliance | Scorecards, surveys, NPS, incidents, HIPAA |
| `11-communication.cy.js` | Communication | Real-time chat, digital signatures, notifications |
| `12-analytics-reporting.cy.js` | Analytics & Reporting | Dashboards, reports, ROI analysis |
| `13-admin-rbac-integrations.cy.js` | Administration | Users, roles, integrations, gamification |

## Setup Instructions

### 1. Copy Test Files to Your Project

Copy the entire `cypress` folder to your NICEHR project root:

```bash
cp -r /path/to/nicehr-tests/cypress /path/to/your/nicehr-project/
cp /path/to/nicehr-tests/cypress.config.js /path/to/your/nicehr-project/
```

### 2. Install Dependencies (if not already installed)

```bash
npm install cypress --save-dev
```

### 3. Seed Test Data

```bash
npx tsx seed.ts
```

This creates the test user (`test@example.com` / `password123`).

### 4. Start Your Application

```bash
npm run dev
```

### 5. Run Tests

**Run all tests (headless):**
```bash
npx cypress run
```

**Run specific test file:**
```bash
npx cypress run --spec "cypress/e2e/03-projects.cy.js"
```

**Open interactive test runner:**
```bash
npx cypress open
```

## Custom Commands

The test suite includes reusable custom commands in `cypress/support/commands.js`:

| Command | Description | Usage |
|---------|-------------|-------|
| `cy.login(email, password)` | Login via UI | `cy.login()` |
| `cy.loginViaApi(email, password)` | Login via API (faster) | `cy.loginViaApi()` |
| `cy.navigateTo(module)` | Navigate to module | `cy.navigateTo('projects')` |
| `cy.selectOption(selector, text)` | Select Radix UI option | `cy.selectOption('[data-testid="select"]', 'Option')` |
| `cy.openModal(buttonTestId)` | Open modal dialog | `cy.openModal('button-create')` |
| `cy.fillField(testId, value)` | Fill form field | `cy.fillField('input-name', 'Value')` |
| `cy.clickButton(testId)` | Click button | `cy.clickButton('button-submit')` |
| `cy.tableRowExists(text)` | Assert table row exists | `cy.tableRowExists('Project Name')` |
| `cy.waitForPageLoad()` | Wait for loading to complete | `cy.waitForPageLoad()` |

## Test Data Attributes

Tests use `data-testid` attributes for reliable element selection. Patterns used:

- `input-*` - Input fields
- `button-*` - Buttons
- `select-*` - Select dropdowns
- `checkbox-*` - Checkboxes
- `tab-*` - Tab triggers
- `filter-*` - Filter controls
- `*-list`, `*-table` - List/table containers
- `*-item`, `*-row` - List/table items

## Adding Test IDs to Your Components

For tests to work, add `data-testid` attributes to your components:

```jsx
// Before
<Button onClick={handleSubmit}>Create Project</Button>

// After
<Button data-testid="button-create-project" onClick={handleSubmit}>Create Project</Button>
```

## CI/CD Integration

The test suite is compatible with GitHub Actions. Example workflow:

```yaml
name: E2E Tests

on: [push, pull_request]

jobs:
  e2e:
    runs-on: ubuntu-latest
    
    services:
      postgres:
        image: postgres:14
        env:
          POSTGRES_DB: nicehr_test
          POSTGRES_USER: postgres
          POSTGRES_PASSWORD: postgres
        ports:
          - 5432:5432
    
    steps:
      - uses: actions/checkout@v3
      
      - uses: actions/setup-node@v3
        with:
          node-version: 20
          cache: 'npm'
      
      - run: npm ci
      
      - name: Seed test data
        run: npx tsx seed.ts
        env:
          DATABASE_URL: postgresql://postgres:postgres@localhost:5432/nicehr_test
      
      - name: Run Cypress tests
        uses: cypress-io/github-action@v6
        with:
          build: npm run build
          start: npm run dev
          wait-on: 'http://localhost:5000'
        env:
          DATABASE_URL: postgresql://postgres:postgres@localhost:5432/nicehr_test
      
      - uses: actions/upload-artifact@v3
        if: failure()
        with:
          name: cypress-screenshots
          path: cypress/screenshots
```

## Troubleshooting

### Tests Failing Due to Missing Elements

Ensure your components have the correct `data-testid` attributes matching the test selectors.

### Radix UI Select Issues

Radix UI selects require special handling. The `cy.selectOption()` custom command handles this:

```javascript
cy.selectOption('[data-testid="select-status"]', 'Active');
```

### WebSocket Errors

WebSocket errors are ignored by default in `cypress/support/e2e.js`. If you need to test WebSocket functionality, modify the error handling.

### Slow Tests

For faster test execution:
1. Use `cy.loginViaApi()` instead of `cy.login()` for tests that don't specifically test the login flow
2. Increase parallelization in CI
3. Use Cypress Dashboard for test analytics

## Extending the Test Suite

To add new tests:

1. Create a new file: `cypress/e2e/XX-module-name.cy.js`
2. Follow the existing patterns for structure
3. Use custom commands for common operations
4. Add appropriate `data-testid` attributes to your components

## Test Statistics

- **Total Test Files:** 13
- **Total Test Suites:** 100+
- **Total Individual Tests:** 400+
- **Estimated Run Time:** ~30-45 minutes (full suite)

## Module Coverage Details

### 11-Phase EHR Implementation (03-projects.cy.js)
- Phase listing and navigation
- Phase steps (CRUD, status updates)
- Phase deliverables (submission, approval workflow)
- Phase risks (register, mitigation, status)
- Phase milestones (tracking, completion)
- RACI matrix (assignments, filtering)

### Role-Based Access Control (13-admin-rbac-integrations.cy.js)
- 4 base roles testing
- 11 implementation roles
- Custom role creation
- 44 permissions across 15 domains
- Project context filtering
- Permission matrix management
