import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../../App';
import DailyIframe from '@daily-co/daily-js';
import {
  Mic,
  MicOff,
  Video,
  VideoOff,
  Monitor,
  PhoneOff,
  Loader2,
  Clock,
  AlertCircle,
  X,
} from 'lucide-react';
import RatingModal from '../../components/support/RatingModal';

interface SessionInfo {
  id: number;
  status: string;
  department: string;
  issueSummary: string;
  consultantName?: string;
  requesterName?: string;
  daily_room_url: string;
  daily_room_name: string;
  started_at?: string;
}

export default function VideoCall() {
  const { sessionId } = useParams<{ sessionId: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [session, setSession] = useState<SessionInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [joining, setJoining] = useState(false);
  const [inCall, setInCall] = useState(false);
  const [error, setError] = useState('');
  const [showRating, setShowRating] = useState(false);
  
  // Call controls state
  const [isMicOn, setIsMicOn] = useState(true);
  const [isCameraOn, setIsCameraOn] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [callDuration, setCallDuration] = useState(0);

  const callFrameRef = useRef<DailyIframe | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const durationIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const isConsultant = user?.role === 'consultant' || user?.role === 'admin';

  // Fetch session info
  useEffect(() => {
    const fetchSession = async () => {
      try {
        const res = await fetch(`/api/support/active?userId=${user?.id}`);
        const data = await res.json();
        
        if (!data || data.id !== parseInt(sessionId!)) {
          setError('Session not found or not authorized');
          setLoading(false);
          return;
        }

        setSession(data);
        setLoading(false);
      } catch (err) {
        console.error('Failed to fetch session:', err);
        setError('Failed to load session');
        setLoading(false);
      }
    };

    fetchSession();
    const interval = setInterval(fetchSession, 5000);
    return () => clearInterval(interval);
  }, [sessionId, user?.id]);

  // Join the call
  const joinCall = useCallback(async () => {
    if (!session?.daily_room_name || !containerRef.current) return;

    setJoining(true);
    setError('');

    try {
      // Get token from server
      const tokenRes = await fetch(`/api/support/join/${sessionId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user?.id,
          userName: user?.name,
          isConsultant,
        }),
      });

      if (!tokenRes.ok) {
        const errorData = await tokenRes.json();
        throw new Error(errorData.error || 'Failed to get call token');
      }

      const { token, roomUrl } = await tokenRes.json();

      // Create Daily.co frame
      const callFrame = DailyIframe.createFrame(containerRef.current, {
        iframeStyle: {
          width: '100%',
          height: '100%',
          border: 'none',
          borderRadius: '12px',
        },
        showLeaveButton: false,
        showFullscreenButton: true,
      });

      callFrameRef.current = callFrame;

      // Set up event handlers
      callFrame.on('joined-meeting', async () => {
        setInCall(true);
        setJoining(false);
        
        // Notify server that call started
        await fetch(`/api/support/start/${sessionId}`, { method: 'POST' });
        
        // Start duration timer
        durationIntervalRef.current = setInterval(() => {
          setCallDuration(prev => prev + 1);
        }, 1000);
      });

      callFrame.on('left-meeting', () => {
        setInCall(false);
        if (durationIntervalRef.current) {
          clearInterval(durationIntervalRef.current);
        }
      });

      callFrame.on('error', (e) => {
        console.error('Daily.co error:', e);
        setError('Video call error occurred');
        setJoining(false);
      });

      // Join the meeting
      await callFrame.join({ url: roomUrl, token });

    } catch (err) {
      console.error('Failed to join call:', err);
      setError(err instanceof Error ? err.message : 'Failed to join call');
      setJoining(false);
    }
  }, [session, sessionId, user, isConsultant]);

  // Leave call and end session
  const endCall = async () => {
    if (callFrameRef.current) {
      await callFrameRef.current.leave();
      callFrameRef.current.destroy();
      callFrameRef.current = null;
    }

    if (durationIntervalRef.current) {
      clearInterval(durationIntervalRef.current);
    }

    // End session on server
    await fetch(`/api/support/end/${sessionId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ endedBy: user?.id }),
    });

    // Show rating for staff
    if (!isConsultant) {
      setShowRating(true);
    } else {
      navigate('/');
    }
  };

  // Toggle controls
  const toggleMic = () => {
    if (callFrameRef.current) {
      callFrameRef.current.setLocalAudio(!isMicOn);
      setIsMicOn(!isMicOn);
    }
  };

  const toggleCamera = () => {
    if (callFrameRef.current) {
      callFrameRef.current.setLocalVideo(!isCameraOn);
      setIsCameraOn(!isCameraOn);
    }
  };

  const toggleScreenShare = async () => {
    if (callFrameRef.current) {
      if (isScreenSharing) {
        await callFrameRef.current.stopScreenShare();
      } else {
        await callFrameRef.current.startScreenShare();
      }
      setIsScreenSharing(!isScreenSharing);
    }
  };

  // Cancel pending request
  const cancelRequest = async () => {
    await fetch(`/api/support/cancel/${sessionId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: user?.id }),
    });
    navigate('/');
  };

  // Format duration
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (callFrameRef.current) {
        callFrameRef.current.destroy();
      }
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
      }
    };
  }, []);

  // Handle rating completion
  const handleRatingComplete = () => {
    setShowRating(false);
    navigate('/');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 text-primary-600 animate-spin" />
      </div>
    );
  }

  if (error && !session) {
    return (
      <div className="max-w-md mx-auto text-center py-12">
        <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Session Error</h2>
        <p className="text-gray-500 mb-4">{error}</p>
        <button
          onClick={() => navigate('/')}
          className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
        >
          Go to Dashboard
        </button>
      </div>
    );
  }

  // Waiting room for pending status
  if (session?.status === 'pending') {
    return (
      <div className="max-w-md mx-auto text-center py-12">
        <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <Loader2 className="w-8 h-8 text-primary-600 animate-spin" />
        </div>
        <h2 className="text-xl font-semibold text-gray-900 mb-2">
          Waiting for a Consultant
        </h2>
        <p className="text-gray-500 mb-6">
          Your request for <span className="font-medium">{session.department}</span> support is in the queue.
          A consultant will connect with you shortly.
        </p>
        <div className="bg-gray-50 rounded-lg p-4 mb-6 text-left">
          <p className="text-sm text-gray-600">
            <span className="font-medium">Issue:</span> {session.issueSummary}
          </p>
        </div>
        <button
          onClick={cancelRequest}
          className="flex items-center gap-2 mx-auto px-4 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <X className="w-4 h-4" />
          Cancel Request
        </button>
      </div>
    );
  }

  // Rating modal
  if (showRating) {
    return (
      <RatingModal
        sessionId={parseInt(sessionId!)}
        userId={user?.id || 0}
        onComplete={handleRatingComplete}
      />
    );
  }

  return (
    <div className="h-[calc(100vh-200px)] flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">
            {session?.department} Support
          </h1>
          <p className="text-sm text-gray-500">
            with {isConsultant ? session?.requesterName : session?.consultantName}
          </p>
        </div>
        {inCall && (
          <div className="flex items-center gap-2 px-3 py-1.5 bg-green-100 text-green-700 rounded-full">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <Clock className="w-4 h-4" />
            <span className="font-medium">{formatDuration(callDuration)}</span>
          </div>
        )}
      </div>

      {/* Video container */}
      <div className="flex-1 bg-gray-900 rounded-xl overflow-hidden relative">
        {!inCall && !joining && (
          <div className="absolute inset-0 flex items-center justify-center">
            <button
              onClick={joinCall}
              className="px-6 py-3 bg-primary-600 text-white font-medium rounded-lg hover:bg-primary-700 transition-colors"
            >
              Join Video Call
            </button>
          </div>
        )}
        
        {joining && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-white">
              <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2" />
              <p>Joining call...</p>
            </div>
          </div>
        )}

        <div ref={containerRef} className="w-full h-full" />
      </div>

      {/* Controls */}
      {inCall && (
        <div className="flex items-center justify-center gap-4 mt-4">
          <button
            onClick={toggleMic}
            className={`p-4 rounded-full transition-colors ${
              isMicOn
                ? 'bg-gray-200 hover:bg-gray-300 text-gray-700'
                : 'bg-red-500 hover:bg-red-600 text-white'
            }`}
            title={isMicOn ? 'Mute microphone' : 'Unmute microphone'}
          >
            {isMicOn ? <Mic className="w-6 h-6" /> : <MicOff className="w-6 h-6" />}
          </button>

          <button
            onClick={toggleCamera}
            className={`p-4 rounded-full transition-colors ${
              isCameraOn
                ? 'bg-gray-200 hover:bg-gray-300 text-gray-700'
                : 'bg-red-500 hover:bg-red-600 text-white'
            }`}
            title={isCameraOn ? 'Turn off camera' : 'Turn on camera'}
          >
            {isCameraOn ? <Video className="w-6 h-6" /> : <VideoOff className="w-6 h-6" />}
          </button>

          <button
            onClick={toggleScreenShare}
            className={`p-4 rounded-full transition-colors ${
              isScreenSharing
                ? 'bg-primary-500 hover:bg-primary-600 text-white'
                : 'bg-gray-200 hover:bg-gray-300 text-gray-700'
            }`}
            title={isScreenSharing ? 'Stop sharing' : 'Share screen'}
          >
            <Monitor className="w-6 h-6" />
          </button>

          <button
            onClick={endCall}
            className="p-4 bg-red-500 hover:bg-red-600 text-white rounded-full transition-colors"
            title="End call"
          >
            <PhoneOff className="w-6 h-6" />
          </button>
        </div>
      )}

      {/* Error display */}
      {error && (
        <div className="mt-4 flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm">{error}</p>
        </div>
      )}
    </div>
  );
}
