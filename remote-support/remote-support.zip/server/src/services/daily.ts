import { v4 as uuidv4 } from 'uuid';

const DAILY_API_KEY = process.env.DAILY_API_KEY!;
const DAILY_DOMAIN = process.env.DAILY_DOMAIN!;
const DAILY_API_URL = 'https://api.daily.co/v1';

interface DailyRoom {
  id: string;
  name: string;
  url: string;
  created_at: string;
  config: {
    max_participants?: number;
    enable_screenshare?: boolean;
    enable_chat?: boolean;
  };
}

interface DailyToken {
  token: string;
}

interface CreateRoomOptions {
  sessionId: number;
  expiryMinutes?: number;
}

interface CreateTokenOptions {
  roomName: string;
  participantId: number;
  participantName: string;
  isOwner?: boolean;
  expiryMinutes?: number;
}

class DailyService {
  private async request<T>(
    endpoint: string,
    method: 'GET' | 'POST' | 'DELETE' = 'GET',
    body?: Record<string, unknown>
  ): Promise<T> {
    const response = await fetch(`${DAILY_API_URL}${endpoint}`, {
      method,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${DAILY_API_KEY}`,
      },
      body: body ? JSON.stringify(body) : undefined,
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Daily.co API error: ${response.status} - ${error}`);
    }

    return response.json();
  }

  /**
   * Create a new video room for a support session
   * Room names are UUIDs to prevent guessing
   */
  async createRoom({ sessionId, expiryMinutes = 120 }: CreateRoomOptions): Promise<{ name: string; url: string }> {
    const roomName = `session-${sessionId}-${uuidv4().slice(0, 8)}`;
    
    const room = await this.request<DailyRoom>('/rooms', 'POST', {
      name: roomName,
      properties: {
        // Room expires after session should be done
        exp: Math.floor(Date.now() / 1000) + expiryMinutes * 60,
        // Enable features
        enable_screenshare: true,
        enable_chat: true,
        // Require token to join (security)
        enable_prejoin_ui: true,
        // Max 2 participants (staff + consultant)
        max_participants: 2,
        // Auto-delete when everyone leaves
        eject_at_room_exp: true,
      },
    });

    return {
      name: room.name,
      url: `https://${DAILY_DOMAIN}/${room.name}`,
    };
  }

  /**
   * Delete a room when session ends
   */
  async deleteRoom(roomName: string): Promise<void> {
    try {
      await this.request(`/rooms/${roomName}`, 'DELETE');
    } catch (error) {
      // Room might already be deleted or expired - that's fine
      console.warn(`Failed to delete room ${roomName}:`, error);
    }
  }

  /**
   * Create a meeting token for a specific participant
   * Tokens are scoped to one room and one user
   */
  async createToken({
    roomName,
    participantId,
    participantName,
    isOwner = false,
    expiryMinutes = 120,
  }: CreateTokenOptions): Promise<string> {
    const result = await this.request<DailyToken>('/meeting-tokens', 'POST', {
      properties: {
        room_name: roomName,
        user_id: String(participantId),
        user_name: participantName,
        // Owner can mute others, remove participants
        is_owner: isOwner,
        // Token expiry
        exp: Math.floor(Date.now() / 1000) + expiryMinutes * 60,
        // Permissions
        enable_screenshare: true,
        start_video_off: false,
        start_audio_off: false,
      },
    });

    return result.token;
  }

  /**
   * Get room information
   */
  async getRoomInfo(roomName: string): Promise<DailyRoom | null> {
    try {
      return await this.request<DailyRoom>(`/rooms/${roomName}`);
    } catch {
      return null;
    }
  }

  /**
   * Check if Daily.co is properly configured
   */
  async healthCheck(): Promise<boolean> {
    try {
      await this.request('/rooms?limit=1');
      return true;
    } catch {
      return false;
    }
  }
}

export const dailyService = new DailyService();
export default dailyService;
